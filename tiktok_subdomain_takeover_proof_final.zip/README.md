
# TikTok Subdomain Takeover Proof – CodeGrunt

This package contains full documentation and proof of a subdomain takeover vulnerability discovered on:

**https://academy-outbound-ads.tiktok.com**

---

## 📁 Contents:

### DNS_Resolution/
- `cname_proof_screenshot.png`: Screenshot showing the subdomain pointing to an unclaimed AWS S3 bucket.
- `dig_academy-outbound-ads.txt`: Optional CLI output showing DNS records (can be generated).

### HTTP_Response/
- `s3_bucket_not_found.png`: Browser error page from AWS S3 indicating that the bucket does not exist.
- `curl_headers.txt`: Optional HTTP headers from subdomain (can be generated).

### Proof_of_Control/
- `codegrunt.html`: Hosted HTML page served via the claimed S3 bucket.
- `hosted_poc_screenshot.png`: Screenshot showing live content served under TikTok's subdomain.

### timeline_summary.txt
- Chronological record of discovery, testing, and subdomain behavior before and after remediation.

### ALL_Screenshots/
- Full set of captured screenshots as raw proof, labeled by timestamp.

---

## 🔒 Analyst Note:

This package was created to assist HackerOne analysts in verifying a reported vulnerability that may no longer be visible due to remediation after report submission. All files were captured in real-time and preserved for transparency.

Prepared by: **CodeGrunt**
